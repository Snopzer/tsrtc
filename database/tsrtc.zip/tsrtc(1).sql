-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2017 at 06:06 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tsrtc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tsrtc_bus_information`
--

CREATE TABLE `tsrtc_bus_information` (
  `id_bus` int(11) NOT NULL,
  `bus_number` varchar(50) NOT NULL,
  `start_location` int(11) NOT NULL,
  `end_location` int(11) NOT NULL,
  `ordinary_bus` tinyint(4) NOT NULL,
  `metro_express` tinyint(4) NOT NULL,
  `metro_deluxe` tinyint(4) NOT NULL,
  `luxery_bus` tinyint(4) NOT NULL,
  `district_bus` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tsrtc_bus_information`
--

INSERT INTO `tsrtc_bus_information` (`id_bus`, `bus_number`, `start_location`, `end_location`, `ordinary_bus`, `metro_express`, `metro_deluxe`, `luxery_bus`, `district_bus`) VALUES
(1, '5K', 1, 2, 1, 1, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tsrtc_bus_type`
--

CREATE TABLE `tsrtc_bus_type` (
  `id_bus_type` tinyint(4) NOT NULL,
  `name_of_bus_type` varchar(50) NOT NULL,
  `min_fare` tinyint(4) NOT NULL,
  `max_fare` tinyint(4) NOT NULL,
  `daypass_fare` tinyint(4) NOT NULL,
  `fare_per_km` tinyint(4) NOT NULL,
  `monthly_pass_general_fare` int(11) NOT NULL,
  `monthly_pass_student_fare` int(11) NOT NULL,
  `quarterly_pass_student_fare` int(11) NOT NULL,
  `quarterly_pass_general_fare` int(11) NOT NULL,
  `male_seats` tinyint(4) NOT NULL,
  `female_seats` tinyint(4) NOT NULL,
  `senior_citizen_seats` tinyint(4) NOT NULL,
  `ac_facility` tinyint(4) NOT NULL COMMENT '0-Not avaible   1-Avaible'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tsrtc_bus_type`
--

INSERT INTO `tsrtc_bus_type` (`id_bus_type`, `name_of_bus_type`, `min_fare`, `max_fare`, `daypass_fare`, `fare_per_km`, `monthly_pass_general_fare`, `monthly_pass_student_fare`, `quarterly_pass_student_fare`, `quarterly_pass_general_fare`, `male_seats`, `female_seats`, `senior_citizen_seats`, `ac_facility`) VALUES
(1, 'Ordinary Bus', 6, 50, 70, 5, 600, 200, 400, 0, 20, 16, 4, 0),
(2, 'Metro Express', 7, 50, 80, 7, 895, 400, 600, 0, 20, 16, 4, 0),
(3, 'Metro Deluxe', 8, 60, 80, 8, 910, 450, 0, 0, 20, 16, 4, 0),
(4, 'Metro Luxury AC', 20, 60, 100, 10, 2000, 0, 0, 0, 20, 16, 4, 1),
(5, 'District Bus', 5, 127, 100, 5, 500, 300, 600, 0, 26, 18, 6, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tsrtc_location_information`
--

CREATE TABLE `tsrtc_location_information` (
  `id_location` int(11) NOT NULL,
  `location_name` varchar(255) NOT NULL,
  `location_type` tinyint(4) NOT NULL COMMENT '0-Not Important    1-Important',
  `bus_stop_type` tinyint(4) NOT NULL COMMENT '0-Normal Stop     1-Request Stop  2-Depot',
  `longitude` decimal(9,6) NOT NULL,
  `latitude` decimal(9,6) NOT NULL,
  `metro_bus_stop` tinyint(4) NOT NULL COMMENT '0-Avaible 1-Not avaible ',
  `district_bus_stop` tinyint(4) NOT NULL COMMENT '0-Avaible 1-Not avaible '
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tsrtc_location_information`
--

INSERT INTO `tsrtc_location_information` (`id_location`, `location_name`, `location_type`, `bus_stop_type`, `longitude`, `latitude`, `metro_bus_stop`, `district_bus_stop`) VALUES
(1, 'Mehdipatnam', 1, 0, '78.440400', '17.395300', 0, 0),
(2, 'Secunderabad Junction', 1, 0, '78.498300', '17.439900', 0, 0),
(3, 'Sarojini Bus Stop', 0, 0, '0.000000', '0.000000', 0, 0),
(4, 'NMDC Bus Stop', 0, 0, '0.000000', '0.000000', 0, 0),
(5, 'Golconda Hotel', 0, 0, '0.000000', '0.000000', 0, 0),
(6, 'Masab Tank Bus Stop', 1, 0, '0.000000', '0.000000', 0, 0),
(7, 'Mahavir Hospital', 0, 0, '0.000000', '0.000000', 0, 0),
(8, 'Lakdikapool Bus Stop', 1, 0, '0.000000', '0.000000', 0, 0),
(9, 'Birla Mandir', 0, 0, '0.000000', '0.000000', 0, 0),
(10, 'Secretariat Bus Stop', 1, 0, '0.000000', '0.000000', 0, 0),
(11, 'TankBund', 1, 0, '0.000000', '0.000000', 0, 0),
(12, 'BoatsClub(RP Road)', 0, 0, '0.000000', '0.000000', 0, 0),
(13, 'DBR Mills', 0, 0, '0.000000', '0.000000', 0, 0),
(14, 'RP Road', 0, 0, '0.000000', '0.000000', 0, 0),
(15, 'Ranigunj Bus Stop', 0, 0, '0.000000', '0.000000', 0, 0),
(16, 'Bible House', 0, 0, '0.000000', '0.000000', 0, 0),
(17, 'Bata(RP Road)', 1, 0, '0.000000', '0.000000', 0, 0),
(18, 'James Street', 0, 0, '0.000000', '0.000000', 0, 0),
(19, 'Mahaboob College', 0, 0, '0.000000', '0.000000', 0, 0),
(20, 'Patny', 0, 0, '0.000000', '0.000000', 0, 0),
(21, 'Clock Tower', 0, 0, '0.000000', '0.000000', 0, 0),
(22, 'Sangeeth', 0, 0, '0.000000', '0.000000', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tsrtc_bus_information`
--
ALTER TABLE `tsrtc_bus_information`
  ADD PRIMARY KEY (`id_bus`);

--
-- Indexes for table `tsrtc_bus_type`
--
ALTER TABLE `tsrtc_bus_type`
  ADD PRIMARY KEY (`id_bus_type`);

--
-- Indexes for table `tsrtc_location_information`
--
ALTER TABLE `tsrtc_location_information`
  ADD PRIMARY KEY (`id_location`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tsrtc_bus_information`
--
ALTER TABLE `tsrtc_bus_information`
  MODIFY `id_bus` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tsrtc_bus_type`
--
ALTER TABLE `tsrtc_bus_type`
  MODIFY `id_bus_type` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tsrtc_location_information`
--
ALTER TABLE `tsrtc_location_information`
  MODIFY `id_location` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
